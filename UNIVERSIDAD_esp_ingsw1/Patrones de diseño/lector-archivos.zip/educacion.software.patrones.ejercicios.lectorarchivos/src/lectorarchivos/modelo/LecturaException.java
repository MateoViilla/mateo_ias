package lectorarchivos.modelo;

public class LecturaException extends Exception {

	public LecturaException(String message) {
		super(message);
	}

	private static final long serialVersionUID = 1L;

}
