package Interfaces;

public interface INotificador {
    public void enviar(String mensaje);
}
